
public interface DVDUserInterface {

	void processCommands();
	
}
