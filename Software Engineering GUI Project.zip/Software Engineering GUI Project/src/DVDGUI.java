import java.awt.Font;

import javax.swing.*;

/**
 *  This class is an implementation of DVDUserInterface
 *  that uses JOptionPane to display the menu of command choices. 
 */

public class DVDGUI implements DVDUserInterface {
	 //private ImageIcon broly = new ImageIcon("DBS-BROLY.PNG");
	 //private ImageIcon sonic = new ImageIcon("Sonic_the_Hedgehog.PNG");
	 //private ImageIcon defaultImg = new ImageIcon("default-movie.PNG");
	 private String defaultImgStr = "movie.PNG";
	 private GUIDVDCollection dvdlist;
	 //private String arrayList;
	 
	 public DVDGUI(GUIDVDCollection dl)
	 {
		 dvdlist = dl;
	 }
	 
	 public void processCommands()
	 {
		 String[] commands = {"Add DVD or Modify selected DVD? ",
				 	"or Remove Selected DVD",
				 	"or Get Selected Rating of DVD",
				 	"or Get Selected RunningTime of DVD",
				 	"Exit and Save"};
		 
		 int choice;
		 //int indexMovieChoice; //Will be passed to the test cases for removing/getting info of certain movie. Have to edit test cases
		 String movieChoice = ""; //Will be used to store movie choice by user and passed to test cases for data operation
		 
		 //System.out.println("Hi");
		 
		 do {
			 movieChoice = dvdlist.getMovieSelection(); //Displays current arrayList. Change to return choice made and name of movie for that choice
			 
			 JLabel newStyle = new JLabel("Select a command");
		     newStyle.setFont(new Font("Times New Roman", Font.BOLD, 40));
		     
			 choice = JOptionPane.showOptionDialog(null,
					 newStyle, 
					 "DVD Collection", 
					 JOptionPane.YES_NO_CANCEL_OPTION, 
					 JOptionPane.QUESTION_MESSAGE, 
					 null, 
					 commands,
					 commands[commands.length - 1]);
		 
			 switch (choice) { //Change test cases to include choice for movie selected by user from getMovieSelection();
			 	case 0: doAddOrModifyDVD(movieChoice); break; 
			 	case 1: doRemoveDVD(movieChoice); break;
			 	case 2: doGetDVDsByRating(movieChoice); break;
			 	case 3: doGetTotalRunningTime(movieChoice); break;
			 	case 4: doSave(); break;
			 	default:  // do nothing
			 }
			 
		 } while (choice != commands.length-1);
		 System.exit(0);
	 }

	private void doAddOrModifyDVD(String movieName) {

		// Request the title
		String decision = JOptionPane.showInputDialog("Do you want to Add a new Movie or Modify the current movie Info? "
				                                      + "Please enter Add or Modify:");
		if(decision == null) {
			return;
		}
		else if(decision.toUpperCase().equals("ADD")) {
			String title = JOptionPane.showInputDialog("Enter title");
			if (title == null) {
				return;		// dialog was cancelled
			}
			title = title.toUpperCase();
			
			// Request the rating
			String rating = JOptionPane.showInputDialog("Enter rating for " + title);
			if (rating == null) {
				return;		// dialog was cancelled
			}
			rating = rating.toUpperCase();
			
			// Request the running time
			String time = JOptionPane.showInputDialog("Enter running time for " + title);
			if (time == null) {
			}
			
	                // Add or modify the DVD (assuming the rating and time are valid
	                dvdlist.addOrModifyDVD(title, rating, time, defaultImgStr);
	                
	                // Display current collection to the console for debugging, change to GUI
	                //System.out.println("Adding/Modifying: " + title + "," + rating + "," + time); //Remove when done with GUI
	                //System.out.println(dvdlist); //Remove when done with GUI
		}
		else if(decision.toUpperCase().equals("MODIFY")) {
			dvdlist.modifyDVD(movieName);
		}
		
		
	}
	
	private void doRemoveDVD(String movieIs) {

		// Request the title
		//String title = JOptionPane.showInputDialog("Enter title");
		String title = movieIs;
		//if (title == null) {
			//return;		// dialog was cancelled
		//}
		title = title.toUpperCase();
		
                // Remove the matching DVD if found
                dvdlist.removeDVD(title);
                
                // Display current collection to the console for debugging
                //System.out.println("Removing: " + title); //Following two lines are for testing purposes
                //System.out.println(dvdlist);
                
                JLabel newStyle = new JLabel("The movie title " + title + " has been removed");
                newStyle.setFont(new Font("Times New Roman", Font.BOLD, 34));
                JOptionPane.showMessageDialog(null, newStyle);

	}
	
	private void doGetDVDsByRating(String movieIs) {
		// Request the rating
		/*String rating = JOptionPane.showInputDialog("Enter rating");
		if (rating == null) {
			return;		// dialog was cancelled
		}*/
		String displayData = "";
		String rated = ""; // To hold current rating of movie
		String curImage = ""; //Holds image attached to current movie 
		String rating = movieIs; //Holds name of movie in which rating will be displayed
		rating = rating.toUpperCase();
		
        String results = dvdlist.getDVDsByRating(rating); //Change to only return DVD rating
        String tempArray[] = results.split(",", 2);
                
        for(int i = 0; i < tempArray.length; i++) {
            if(i == 0) {
              	rated = tempArray[i];
            }
            else {
            	curImage = tempArray[i];
            }
        }
        displayData = "The movie " + rating + " is rated " + rated;
        //System.out.println(curImage);
        //System.out.println("DVDs with rating " + rating);
        //System.out.println(results); 
        //JOptionPane.showMessageDialog(null, results, "Displaying DVD Rating", JOptionPane.INFORMATION_MESSAGE, broly);
                
        JLabel newStyle = new JLabel(displayData);
        newStyle.setFont(new Font("Times New Roman", Font.ITALIC, 34));
        JOptionPane.showMessageDialog(null, newStyle, "Displaying DVD Rating", JOptionPane.INFORMATION_MESSAGE, new ImageIcon(curImage));

	}

        private void doGetTotalRunningTime(String movieIs) {
                String curStr = "", curTotal = "", curImage = "";
                int totalTime = 0;
        	
                String movieInfo = dvdlist.getTotalRunningTime(movieIs);
                
                String tempArray[] = movieInfo.split(",", 2);
                
                for(int i = 0; i < tempArray.length; i++) {
                	if(i == 0) {
                		curTotal = tempArray[i];
                		totalTime = Integer.parseInt(curTotal);
                	}
                	else {
                		curImage = tempArray[i];
                	}
                }
                curStr = "Total Running Time of " + movieIs + ": " + totalTime + " minutes";
                //System.out.println(total + " minutes");
                
                JLabel newStyle = new JLabel(curStr);
                newStyle.setFont(new Font("Times New Roman", Font.ITALIC, 34));
                JOptionPane.showMessageDialog(null, newStyle, "Displaying DVD RunningTime", JOptionPane.INFORMATION_MESSAGE, new ImageIcon(curImage));
                
        }

	private void doSave() {
		
		dvdlist.save();
		
	}
		
}
