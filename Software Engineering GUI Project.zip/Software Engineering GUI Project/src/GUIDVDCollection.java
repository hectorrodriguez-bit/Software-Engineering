import java.awt.Font;
import java.io.*;
import java.util.Scanner;
import javax.swing.*;
//import java.util.ArrayList;

public class GUIDVDCollection{

	// Data fields
	//private String curList[] = {"Hi"}; //Will be used for display GUI method
	
	/** The current number of DVDs in the array */
	private int numdvds;
	
	/** The array to contain the DVDs */
	private DVD[] dvdArray;
	
	/** The name of the data file that contains dvd data */
	private String sourceName;
	
	/** Boolean flag to indicate whether the DVD collection was
	    modified since it was last saved. */
	//private boolean modified; //Not used
	
	/**
	 *  Constructs an empty directory as an array
	 *  with an initial capacity of 7. When we try to
	 *  insert into a full array, we will double the size of
	 *  the array first.
	 */
	
	public GUIDVDCollection() {//Default constructor called each time new DVDCollection is made
		numdvds = 0;
		dvdArray = new DVD[7]; 
	}
	
	public String toString() {
		// Return a string containing all the DVDs in the
		// order they are stored in the array along with
		// the values for numdvds and the length of the array.
		// See homework instructions for proper format.
		String allDVDs = "";
		//dvdsTotal(dvdArray); // Change to type void just update numdvds, don't need
		allDVDs = "numdvds = " + numdvds + "\n" + "dvdArray.length = " + dvdArray.length + "\n";
		allDVDs = allDVDs + listDVDs(dvdArray);
		
		return allDVDs;	
	}

	public void addOrModifyDVD(String title, String rating, String runningTime, String imageInfo) {
		// NOTE: Be careful. Running time is a string here
		// since the user might enter non-digits when prompted.
		// If the array is full and a new DVD needs to be added,
		// double the size of the array first.
		String tempStr = "", tempRating = "", imageStr = "";
		int tempTime = 0;
		int tempLength = dvdArray.length;
		DVD [] tempDVDs = {};
		
		//If full create temp dvd array and copy data over, then add
        //new data from user, when done overwrite dvdArray with new
        //size and data from temp Array
		//if(dvdArray.length == tempLength) { //Change to check if last index in array has value
		//if(!dvdArray[dvdArray.length - 1].getTitle().equals("")) {
		if(!(dvdArray[dvdArray.length - 1].getTitle().equals(""))) {
			tempDVDs = new DVD[tempLength * 2];
			tempLength = tempLength * 2;
			allocateArray(tempDVDs, tempLength);
			
			for(int i = 0; i < dvdArray.length; i++) { //Copy data from dvdArray to tempArray
				tempStr = dvdArray[i].getTitle();
				tempDVDs[i].setTitle(tempStr);
				
				tempRating = dvdArray[i].getRating();
				tempDVDs[i].setRating(tempRating);
				
				tempTime = dvdArray[i].getRunningTime();
				tempDVDs[i].setRunningTime(tempTime);
				
				imageStr = dvdArray[i].getImage();
				tempDVDs[i].setDVDImage(imageStr);
				//modified = true;
			}
			
			for(int i = 0; i < tempLength; i++) { //Add new data into temp array 
				if(tempDVDs[i].getTitle().equals(title.toUpperCase())) {
					System.out.println("That movie is in already in the library. Exiting now!");
					break;
				}
				else if(tempDVDs[i].getTitle().equals("")) {
					tempDVDs[i].setTitle(title.toUpperCase());
					tempDVDs[i].setRating(rating);
					tempDVDs[i].setRunningTime(Integer.parseInt(runningTime)); //Converts string to num
					tempDVDs[i].setDVDImage(imageInfo);
					numdvds = numdvds + 1;
					//modified = true;
					break;
				}
			}
			
			dvdArray = new DVD[tempLength];
			
			for(int i = 0; i < tempLength; i ++) { // Copy data back to original array, do deep copy when fix first portion
				dvdArray[i] = tempDVDs[i];
			}
			
		}
		else { //Array is not full, add new data to array if does not already exist
			for(int i =0; i < dvdArray.length; i++) {
				if(dvdArray[i].getTitle().equals(title.toUpperCase())) { //Already in library exit
					//numdvds = numdvds + 1;
					break;
				}
				else if(dvdArray[i].getTitle().equals("")) {
					dvdArray[i].setTitle(title.toUpperCase());
					dvdArray[i].setRating(rating);
					dvdArray[i].setRunningTime(Integer.parseInt(runningTime));
					dvdArray[i].setDVDImage(imageInfo);
					numdvds = numdvds + 1;
					//modified = true;
					
					/*tempStr = dvdArray[i].getTitle(); //This while block is for testing
					System.out.println(tempStr + "\n");
					
					tempRating = dvdArray[i].getRating();
					System.out.println(tempRating + "\n");
					
					tempTime = dvdArray[i].getRunningTime();
					System.out.println(tempTime + "\n");*/
					
					break;
				}
			}
		}
		//Maybe create method to copy data from one array to another
		//Create for loop that overwrites dvdArray with new size, then copies data from temp to dvdArray
		//System.out.println(toString()); //Uncomment to display the file loading in at each instance
	}
	
	public void removeDVD(String title) {
		String tempTitle = "", tempRating = "", tempImage = "";
		int tempTime = 0, updateCounter = 0;
		//boolean keepGoing = true; //Counter to keep looping if we have a string
		boolean stopLoop = false;
		
		for(int i = 0; i < dvdArray.length; i++) {
			if(dvdArray[i].getTitle().equals(title.toUpperCase())) {
					for(int j = i; j < dvdArray.length; j++) {
						if(!dvdArray[j].getTitle().equals("")) {
							if(j == dvdArray.length - 1) {
								dvdArray[j].setTitle("");
								dvdArray[j].setRating("");
								dvdArray[j].setRunningTime(0);
								dvdArray[j].setDVDImage("");
								updateCounter++;
							}
							else {
								tempTitle = dvdArray[j + 1].getTitle();
								dvdArray[j].setTitle(tempTitle);
								
								//System.out.println("Hi I am tempTitle " + tempTitle);
								
								tempRating = dvdArray[j + 1].getRating();
								dvdArray[j].setRating(tempRating);
								
								//System.out.println("Hi I am array element" + j + dvdArray[j]);
								
								tempTime = dvdArray[j + 1].getRunningTime();
								dvdArray[j].setRunningTime(tempTime);
								
								tempImage = dvdArray[j + 1].getImage();
								dvdArray[j].setDVDImage(tempImage);
								
								updateCounter++;
							}
						}
						else {//If current index is empty, then break
							//keepGoing = false;
							break;
						}
					}
				stopLoop = true;//Stop loop once title to erase was found and array changed
			}
			
			if(stopLoop) { // Title was removed, stop iteration of for loop
				break;
			}
		}
		if(updateCounter > 0) //Array changed decrement to reflect that array changed
			numdvds--;
		else {
			System.out.println("Movie title does not exist, please make another "
					+ " selection");
		}
		
		//System.out.println(toString());

	}
	
	public String getDVDsByRating(String rating) {
		String listRatings = "", currentRating = "", curTitle = "";
		String curImage;
		//boolean notInList = false; //keeps track if rating is in list
		//int tempLength = dvdArray.length - 1;
		
		for(int i = 0; i < dvdArray.length; i++) {
			currentRating = dvdArray[i].getRating(); //Back indent once
			curTitle = dvdArray[i].getTitle();
			curImage = dvdArray[i].getImage();
			//System.out.println("Here is image" + curImage);
				
			if(!curTitle.equals("")) {
				if(curTitle.equals(rating.toUpperCase())) {
					//listRatings = "The movie " + rating + " has a rating of " + currentRating + "\n";
					//System.out.println("Here is image" + curImage);
					listRatings = currentRating + "," + curImage;
					break;
				}
			}
			else {//Current cell is empty just break out of loop
				//notInList = true; //At this point rating was not found
				break;
			}
		}
		/*if(notInList) {
			listRatings = "Movie with " + rating + " rating does not exist";
		}*/
		//System.out.println(listRatings);
		return listRatings;	// STUB: Remove this line.

	}

	public String getTotalRunningTime(String movieName) { //Change back to return int if needed
		int totalRunTime = 0; //curRunTime = 0;
		String curTitle = "", curImage = "";
		String movieInfo = "";
		
		for(int i = 0; i < dvdArray.length; i++) {
			curTitle = dvdArray[i].getTitle();
			if(!curTitle.equals("")) {
				if(curTitle.equals(movieName)) {
					curImage = dvdArray[i].getImage();
					totalRunTime = dvdArray[i].getRunningTime();
					movieInfo = totalRunTime + "," + curImage;
					break;
				}
				//curRunTime = dvdArray[i].getRunningTime();
				//totalRunTime += curRunTime;
			}
			else {//Current index empty exit loop
				break;
			}
		}

		return movieInfo;	// STUB: Remove this line.
	}

	
	public void loadData(String filename) {
		sourceName = filename; // May not need this line delete if not needed H.R
		File movieFile = new File(filename);
		String fileData = ""; //May not not currentString delete if not used
		String title = "", rating = "", runningTime = "";
		String image = ""; //Try to see if can add icon to initialization if can't then remove
		int tempLength = dvdArray.length;
		//dvdArray = new DVD[7]; //Take off if doesn't work
		//dvdArray = n
		allocateArray(dvdArray, tempLength);
		

		try {
			if(!movieFile.exists()) { //File does not exist exit program
				//dvdArray = {};
				System.out.println("File does not exist! Exiting Program!");
				System.exit(0);
			}
			else {
				Scanner movieStr = new Scanner(movieFile);
				
				while(movieStr.hasNext()) {
					fileData = movieStr.nextLine();
					String[] tempArray = fileData.split(",", 4); //Change back to 3 if doesn't work
					
					//for(int i = 0; i < dvdArray.length; i ++) {
					for(int i = 0 ; i < tempArray.length; i++) {
						if(i == 0) {//Change i mod 3 to just == 0
							title = tempArray[i];
						}
						else if(i == 1){ //Change i mod 3 to just == 1
							rating = tempArray[i];
						}
						else if(i == 2){ //Remove condition to none if adding image icon doesn't work
							runningTime = tempArray[i];
						}
						else {
							image = tempArray[i];
						}
					}
					//System.out.println(tempArray.length);
					//System.out.println(image);
					//System.out.println(title + " " + rating + " " + runningTime);//For testing Purposes
					addOrModifyDVD(title, rating, runningTime, image); //Creating exception, because object for array not created yet
					/*if(fileData != ",") {
						currentString = currentString + " " + fileData;
					}*/
					
				}
				movieStr.close();
			}
		}catch(Exception e) {
			System.out.println("File does not exist! Exiting Now! Hi!");
			System.err.println("Error" + e);
			System.exit(0);
		}
	}
	
	public void save() {//Overwrite original file and store new data into text file
		File inputFile = new File(sourceName);
		String title = "", rating = "", currentStr = "", curImage = "";
		int runningTime = 0;
		
		try {
			FileWriter writeFile = new FileWriter(inputFile);
			
			for(int i = 0; i < dvdArray.length; i++) {
				if(!dvdArray[i].getTitle().equals("")) {
					title = dvdArray[i].getTitle();
					rating = dvdArray[i].getRating();
					runningTime = dvdArray[i].getRunningTime();
					curImage = dvdArray[i].getImage();
					
					currentStr = title + "," + rating + "," + runningTime + "," + curImage + "\n";
					writeFile.write(currentStr);
					//System.out.println("File contents overwritten with new data!");
					//writeFile.write(",");
					//writeFile
				}
			}
			writeFile.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Additional private helper methods go here:
	public String listDVDs(DVD[] arrayDVD) { //Gets current List
		String tempString = "";
		
		for(int i = 0; i < arrayDVD.length; i++) {
			if(!(arrayDVD[i].getTitle().equals("")) ) { //If not equals empty return true
				tempString = tempString + "dvdArray[" + i + "] = " + arrayDVD[i].getTitle()
						     + "/" + arrayDVD[i].getRating() + "/" + arrayDVD[i].getRunningTime() + "\n";
			}
		}
		return tempString;
	}
	
	/*public DVD [] copyArray(DVD [] curArray, int size) { //Delete if not used
		DVD[] newArray = new DVD[size];
		for(int i = 0; i < size; i++) {
			
		}
		
		return curArray;
	}*/
	
	/*public DVD[] returnArray() {//Take out if not used
		return dvdArray;
	}*/
	
	public void allocateArray(DVD[] curArray, int length) {
		for(int i = 0; i < length; i++) {
			curArray[i] = new DVD("", "", 0, "movie.PNG"); // Change back to dvdArray if needed
		}
	}
	
	public int getLength() { //Take out if not used
		return dvdArray.length;
	}
	
	public String getMovieSelection() { //Called from DVDGUI. Displays GUI of current list. Returns movieName selected
		int tempLength = 0; //Will be used to store length of total number of DVDS in the list, excluding the empty cells.
		int choice = 0; //Will be used to store which DVD was selected
		String movieName = ""; //Will return name of Movie that was selected by dialogue box
		//String curImage = "", curTitle = "";
		
		for(int i = 0; i < getLength(); i++) {
			if(!(dvdArray[i].getTitle().equals("")) ) {
				tempLength++;
			}
		}
	
		String curList[] = new String[tempLength]; //Used to store current list of movie titles along with info. Used for jPane
		
		for(int i = 0; i < getLength(); i++) {
			if(!(dvdArray[i].getTitle().equals("")) ) { //If not equals empty return true
				curList[i] = "dvdArray[" + i + "] = " + dvdArray[i].getTitle()
						     + "/" + dvdArray[i].getRating() + "/" + dvdArray[i].getRunningTime() + "\n";
			}
		}
		
		JTextField movieMessage = new JTextField("Select a movie from the following options");
		//JTextField outerMessage = new JTextField( "DVD Collection");
        movieMessage.setFont(movieMessage.getFont().deriveFont(Font.ITALIC, 24));
        //outerMessage.setFont(outerMessage.getFont().deriveFont(Font.BOLD, 24));
        
        JLabel label = new JLabel("Select a movie from the following options");
        label.setFont(new Font("Times New Roman", Font.BOLD, 40));
        
		choice = JOptionPane.showOptionDialog(null,
				 label, 
				 "DVD Collection", 
				 JOptionPane.YES_NO_CANCEL_OPTION, 
				 JOptionPane.QUESTION_MESSAGE, 
				 new ImageIcon("screen.PNG"), 
				 curList,
				 curList[curList.length - 1]);
		
		movieName = dvdArray[choice].getTitle();
		
		//System.out.println(movieName); //For Testing purposes
		return movieName; //Change back to return choice; if needed
	}
	
	public void modifyDVD(String movieName) {
		String curTitle = "";
		String newRating = "";
		String newTime = "";
		//String decision = "";
		
		String decision = JOptionPane.showInputDialog("Do you want to modify the rating or running time of the movie title " + movieName + ". " 
									+ "Please enter rating or running time: ");
		
		if(decision == null) { //User changed their mind
			return;
		}
		else if(decision.toUpperCase().equals("RATING")) {
			for(int i = 0; i < dvdArray.length; i++) {
				curTitle = dvdArray[i].getTitle();
				if(!curTitle.equals("")) {
					if(curTitle.equals(movieName)) {
						newRating = JOptionPane.showInputDialog("Please enter the new rating for the movie " + movieName);
						dvdArray[i].setRating(newRating.toUpperCase());
					}
				}
			}
		}
		else if(decision.toUpperCase().equals("RUNNING TIME")) {
			for(int i = 0; i < dvdArray.length; i++) {
				curTitle = dvdArray[i].getTitle();
				if(!curTitle.equals("")) {
					if(curTitle.equals(movieName)) {
						newTime = JOptionPane.showInputDialog("Please enter the new running time for the movie " + movieName);
						dvdArray[i].setRunningTime(Integer.parseInt(newTime));
					}
				}
			}
		}
	}

}

