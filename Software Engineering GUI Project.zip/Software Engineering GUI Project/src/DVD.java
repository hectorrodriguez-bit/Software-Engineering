public class DVD {

	// Fields:

	private String title;		// Title of this DVD B.H, Take off "" if not needed I added those H.R
	private String rating;		// Rating of this DVD
	private int runningTime;	// Running time of this DVD in minutes
	private String image;    //change back to imageIcon if needed

	public DVD(String dvdTitle, String dvdRating, int dvdRunningTime, String DVDImage) 
	{
		title = dvdTitle;
		rating = dvdRating;
		runningTime = dvdRunningTime;
		image = DVDImage;
	}
	
	public String getTitle() 
	{
		return title;	
	}
	
	public String getRating() 
	{
		return rating;	
	}
	
	public int getRunningTime() 
	{
		return runningTime;	
	}
	
	public String getImage() {
		return image;
	}

	public void setTitle(String newTitle) {
		title = newTitle;
	}

	public void setRating(String newRating) {
		rating = newRating;
	}

	public void setRunningTime(int newRunningTime) {
		runningTime = newRunningTime;
	}
	
	public void setDVDImage(String newImage) {
		image = newImage;
	}

	public String toString() {
		return title + "\n" + rating + "\n" + runningTime;
	}
}
