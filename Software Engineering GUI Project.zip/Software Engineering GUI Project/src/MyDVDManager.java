import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;  
import javax.swing.JFrame;

/**
 * 	Program to display and modify a simple DVD collection
 */

@SuppressWarnings("serial")
public class MyDVDManager extends JFrame{

	public static void main(String[] args) throws IOException, InterruptedException {
		String fileName; //Will be used to store file input by GUI text box
		DVDUserInterface dlInterface;
		GUIDVDCollection dl = new GUIDVDCollection();
		GUITextField textFieldFrame = new GUITextField(); 
	    textFieldFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	    textFieldFrame.setSize(350, 100); 
	    textFieldFrame.setVisible(true); 
	    
	    //lock.lock();
		do {
			Thread.sleep(500);
	    } while(textFieldFrame.getDVDFile() == null);
		
		TimeUnit.SECONDS.sleep(4);
		textFieldFrame.setVisible(false);
	    
	    fileName = textFieldFrame.getDVDFile();
	    //System.out.println(fileName);
	    
	    //textFieldFrame.setVisible(true); 
		
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		
		dl.loadData(fileName);

		//textFieldFrame.setVisible(false);
		dlInterface = new DVDGUI(dl);
		dlInterface.processCommands();
		//textFieldFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
}

