import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JTextField;
//import javax.swing.JPasswordField;
import javax.swing.JOptionPane;

@SuppressWarnings("serial")
public class GUITextField extends JFrame{
	private JTextField inputDVDFile;
	private String dvdFile;

	public GUITextField() {
		// TODO Auto-generated constructor stub
		//Container container = getContentPane();
		//container.setLayout(new FlowLayout());
		super("Please input the DVD file");
		setLayout(new FlowLayout());
		
		inputDVDFile = new JTextField(12);
		add(inputDVDFile);
		
		TextFieldHandler inputDVDHandler = new TextFieldHandler();
		inputDVDFile.addActionListener(inputDVDHandler);
	}
	
	public class TextFieldHandler implements ActionListener {
		private String fileDVD;
		
		public void actionPerformed(ActionEvent event) {
			fileDVD = ""; //Will be used to store and display DVD file input by user. Change back to local variable, instead of private if needed
			//String DVDIs = ""; //Stores only the action command without extra formatting
			
			if(event.getSource() == inputDVDFile) {
				fileDVD = event.getActionCommand();
				setDVDFile(fileDVD);
				//System.out.println(getDVDFiles());
			}
			JOptionPane.showMessageDialog(null, "DVD File: " + dvdFile + "\n" + "File has been input window will now close");
			//JOptionPane.showMessageDialog(null, "File has been input window will now close");
		}
		public void setDVDFile(String fileName) {
			dvdFile = fileName;
			//fileDVD = fileName;
		}
	}
	
	public String getDVDFile() {
		return dvdFile;
	}
}
